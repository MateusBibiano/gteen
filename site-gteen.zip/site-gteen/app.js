import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

gsap.registerPlugin(ScrollTrigger, Flip);
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const RM = matchMedia('(prefers-reduced-motion: reduce)').matches;
const TOUCH = matchMedia('(hover:none),(pointer:coarse)').matches;
const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const easeIO = t => t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
const brl = v => v.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const lerpAng = (a, b, t) => { let d = b - a; while (d > Math.PI) d -= Math.PI * 2; while (d < -Math.PI) d += Math.PI * 2; return a + d * t };

/* =====================================================================
   DATA (Tecnologia & Engenharia + Organização & Método · TBR 2026)
   ===================================================================== */
const MEMBERS = [['Mateus David', 'Líder de Tecnologia', ['TEC', 'DP'], 'm-mateus-david'], ['Lucas Leite', 'Líder de Organização', ['ORG'], 'm-lucas'], ['Ricardo Livianu', 'Gestor de Tecnologia', ['TEC', 'DP'], 'm-ricardo'], ['Heitor Nunes', 'Gestor de Organização', ['ORG'], 'm-heitor'], ['Augusto Moni', 'Operador de Mesa', ['TEC', 'DP'], 'm-augusto'], ['João Zoccal', 'Pesquisador', ['MC'], 'm-joao'], ['Mariana Ventura', 'Pesquisadora', ['MC'], 'm-mariana'], ['Gustavo Tiengo', 'Apoio Técnico', ['TEC'], 'm-gustavo'], ['Pedro Lerner', 'Apoio Técnico', ['TEC'], 'm-pedro'], ['Davi Moreira', 'Marketing', ['ORG', 'MC'], 'm-davi']];
const HIST = [{ y: '2010', t: 'FIRST LEGO League', p: 'Início das ações da equipe na FLL.', hi: 1 }, { y: '2014', t: 'Estreia no TBR', p: 'Encerra a FLL e estreia no TBR. Nacional em Nova Iguaçu (RJ).' }, { photo: 'historia-1.jpg', alt: 'Integrantes da GTEeN em uma edição anterior do torneio', p: 'Edições anteriores: o azul já era marca registrada.' }, { y: '2015', t: 'Nova Iguaçu · RJ', p: 'Etapa nacional.' }, { y: '2016', t: 'Rio de Janeiro · RJ', p: 'Etapa nacional.' }, { y: '2017', t: 'Uberlândia · MG', p: 'Etapa nacional.' }, { y: '2018', t: 'Belo Horizonte · MG', p: 'Etapa nacional.' }, { y: '2019', t: 'Guarulhos · SP', p: 'Campeã nacional · Middle 2.' }, { y: '2020', t: 'Virtual', p: 'Edição nacional on-line.', o: 1 }, { y: '2021', t: 'Virtual', p: 'Edição nacional on-line.', o: 1 }, { photo: 'historia-2.jpg', alt: 'Equipe GTEeN com a bandeira da equipe no Torneio Brasil de Robótica', p: 'Com a bandeira da GTEeN no TBR.' }, { y: '2022', t: 'Rio de Janeiro · RJ', p: 'Etapa nacional.' }, { y: '2023', t: 'Brasília · DF', p: 'Etapa nacional.' }, { y: '2024', t: 'Vila Velha · ES', p: 'Etapa nacional.' }, { y: '2025', t: 'Espírito Santo', p: 'Etapa nacional.' }, { y: '2026', t: 'Curitiba · PR', p: 'Classificada para a etapa nacional. Muitos ex-integrantes seguem carreira em engenharia e tecnologia.', hi: 1 }];
const PREMIOS = [[2014, 'Desafio Prático', 'Middle', 'Nacional', 1], [2014, 'Desempenho Geral', 'Middle', 'Nacional', 2], [2015, 'Organização e Método', 'Middle', 'Nacional', 1], [2016, 'Tecnologia e Engenharia', 'Middle', 'Regional', 1], [2017, 'Mérito Científico', 'Middle', 'Regional', 1], [2018, 'Desempenho Geral', 'Middle', 'Regional', 1], [2018, 'Desafio Prático', 'Middle', 'Regional', 1], [2018, 'Mérito Científico', 'Middle', 'Nacional', 2], [2019, 'Desempenho Geral', 'Middle 2', 'Regional', 1], [2019, 'Desempenho Geral', 'Middle 2', 'Nacional', 1], [2020, 'Desempenho Geral', 'Middle 2', 'Regional', 1], [2020, 'Tecnologia e Engenharia', 'Middle 2', 'Nacional', 1], [2021, 'Desempenho Geral', 'Middle 2', 'Regional', 1], [2021, 'Desempenho Geral', 'Middle 2', 'Nacional', 3], [2023, 'Desempenho Geral', 'High', 'Regional', 1], [2024, 'Desempenho Geral', 'Middle 2', 'Regional', 1], [2024, 'Desempenho Geral', 'Middle 2', 'Nacional', 2]];
const MISSOES = [[1, 'Balanço controlado', 'Inclinar a gangorra para o lado oposto até tocar as áreas corretas.', '30'], [2, 'Equilíbrio dinâmico', 'Colocar os blocos da alvenaria sobre o primeiro pavimento, mantendo a estrutura equilibrada.', '75+25'], [3, 'Acessibilidade', 'Levar a rampa até o pátio elevado, criando um acesso acessível.', '32'], [4, 'Segurança no trabalho', 'Pendurar os blocos de EPI nas estruturas da mesma cor.', '100'], [5, 'Conexão do conhecimento', 'Completar o quebra-cabeça com a peça faltante.', '48'], [6, 'Acesso seguro', 'Colocar o carrinho dentro da área verde.', '40'], [7, 'Abertura do saber', 'Levantar a bandeira para inaugurar a escola.', '30'], [8, 'Missão Maker', 'Levar os trabalhadores, liberar o kit de educação tecnológica e levá-lo à Área Escolar.', '68'], [9, 'Entrada inclusiva', 'Terminar a partida com o robô sobre o pátio elevado.', '52']];
const RESULT = [['Balanço controlado', 6, 30], ['Equilíbrio dinâmico', 10, 100], ['Acessibilidade', 8, 32], ['Segurança no trabalho', 12, 100], ['Conexão do conhecimento', 14, 48], ['Acesso seguro', 9, 40], ['Abertura do saber', 8, 30], ['Entrada inclusiva', 7, 52], ['Missão Maker', 46, 68]];
const GARRAS = [
  { t: 'Coleta inicial', s: 1, tags: ['Equilíbrio dinâmico', 'Conexão do conhecimento'], p: 'Coleta os três blocos de alvenaria de uma só vez e, no mesmo deslocamento, a peça do quebra-cabeça. Uma única saída substitui várias operações.' },
  { t: 'Cinco missões, uma saída', s: 2, tags: ['Balanço controlado', 'Conexão do conhecimento', 'Equilíbrio dinâmico', 'Acesso seguro', 'Abertura do saber'], p: 'O mecanismo mais completo da equipe: aciona a gangorra, encaixa a peça, deposita os blocos, entrega o carrinho e aciona a alavanca, sem voltar à base.' },
  { t: 'Garra fixa passiva', s: 3, tags: ['Missão Maker'], p: 'Coleta os trabalhadores. Os testes mostraram que uma solução sem motor era mais robusta, leve e repetível: a eficiência vem da geometria e da precisão do deslocamento.' },
  { t: 'Módulos + ultrassônico', s: 4, tags: ['Segurança no trabalho', 'Missão Maker'], p: 'Dispositivos modulares para duas missões. Um sensor ultrassônico confirma a chegada dos trabalhadores e só então o motor abre a fresta que libera o kit.' },
  { t: 'Leve e confiável', s: 5, tags: ['Acessibilidade', 'Entrada inclusiva'], p: 'A construção mais simples, de propósito: aciona a rampa e conduz o robô até o pátio elevado. Na última saída, o que importa é não falhar.' }];
// 5 saídas on the official mat (u,v in 0..1 of the mat image). cps: [controlPointIdx, tag, name, points, seconds]
const SAIDAS = [
  { txt: 'Coleta os blocos de alvenaria e, na volta, a peça do quebra-cabeça. Deposita tudo na base.', pts: [[.07, .5], [.2, .3], [.33, .55], [.38, .8], [.35, .62], [.2, .56], [.07, .5]], cps: [[3, 'Coleta', 'Blocos de alvenaria', 0, 0], [4, 'Coleta', 'Peça do quebra-cabeça', 0, 0]] },
  { txt: 'Balanço Controlado, Conexão do Conhecimento, Equilíbrio Dinâmico, Acesso Seguro e Abertura do Saber. Ao final, o robô é retirado da mesa.', pts: [[.07, .5], [.09, .72], [.12, .88], [.3, .62], [.59, .38], [.62, .65], [.63, .88], [.78, .62], [.91, .22], [.86, .55], [.89, .8]], cps: [[2, 'M1', 'Balanço controlado', 30, 6], [4, 'M5', 'Conexão do conhecimento', 48, 14], [6, 'M2', 'Equilíbrio dinâmico', 100, 10], [8, 'M6', 'Acesso seguro', 40, 9], [10, 'M7', 'Abertura do saber', 30, 8]] },
  { txt: 'Coleta os trabalhadores com a garra fixa e volta para a base.', pts: [[.07, .5], [.05, .34], [.06, .2], [.1, .34], [.07, .5]], cps: [[2, 'Coleta', 'Trabalhadores', 0, 0]] },
  { txt: 'Segurança no Trabalho e Missão Maker, com o ultrassônico confirmando a chegada dos trabalhadores. Ao final, o robô é retirado da mesa.', pts: [[.07, .5], [.28, .36], [.44, .12], [.62, .1], [.8, .1], [.92, .45], [.95, .82]], cps: [[2, 'M4', 'Segurança no trabalho', 100, 12], [6, 'M8', 'Missão Maker', 68, 46]] },
  { txt: 'Acessibilidade e, por fim, Entrada Inclusiva: o robô termina sobre o pátio elevado.', pts: [[.07, .5], [.12, .7], [.2, .84], [.34, .86], [.46, .86]], cps: [[3, 'M3', 'Acessibilidade', 32, 8], [4, 'M9', 'Entrada inclusiva', 52, 7]] }];
const BLOCOS = [['Ação', 'Modificam aspectos físicos do robô.', ['Movimentação', 'Sons', 'Luzes e tela']], ['Sensores', 'Captam dados do ambiente, fora do robô.', ['Leitura de sensores', 'Calibragem']], ['Controle', 'Interferem no fluxo da programação: repetir, pausar, decidir.', ['if / else', 'loop', 'while', 'Espera']], ['Lógica', 'Tratam valores booleanos: verdadeiro ou falso.', ['Comparação', 'e / ou']], ['Matemática', 'Tratam valores numéricos, como leituras e variáveis.', ['Operações matemáticas']], ['Cores', 'Comparam a leitura do sensor com a cor correspondente.', ['Azul', 'Verde']], ['Variáveis', 'Permitem usar as variáveis criadas.', ['Variáveis personalizadas']], ['Eventos', 'Iniciam a programação a partir de um evento.', ['Quando o programa iniciar']]];
const SS = [['Curvas em alta velocidade', 'Imprecisão que gerava uma sequência de falhas.', 'Sensores de cor na frente buscam referências de cores e linhas: curvas precisas.', 'Programação'], ['Seguidor verdadeiro/falso', 'A lógica só considerava a leitura atual dos sensores.', 'Seguidor com lógica PD/PID: mais preciso mesmo em alta velocidade.', 'Programação'], ['Garra motorizada', 'Coletar os funcionários com motor era complexo demais.', 'Garra fixa: menos complexidade e mais confiabilidade nas partidas.', 'Estrutura'], ['Uma garra só', 'Impossível executar todas as missões com um único acessório.', 'Engate rápido: trocas ágeis, seguras e padronizadas entre as saídas.', 'Estrutura'], ['Centro de massa', 'Tendência a tombar em acelerações e mudanças bruscas.', 'Elementos reposicionados e chassi ajustado: ágil e estável.', 'Estrutura']];
const STEPS = [['Investigar', 'Pesquisa científica, análise dos ODS, estudo bibliográfico, definição do problema e regras do Desafio Prático.'], ['Coletar dados', 'Formulários, dados quantitativos, evidências, análise de desempenho e previsão de custos.'], ['Priorizar', 'Matriz GUT, verificação das ações e atenção aos prazos.'], ['Desenvolver', 'Ideação, construção do robô, programação, testes e integração de tecnologias.'], ['Validar', 'Novas testagens, coleta de resultados, ajustes e melhorias.'], ['Documentar', 'Diário de bordo, Trello, relatórios e compartilhamento com a comunidade.']];
const GANTT = [['Seleção de novos membros e debate do tema', 0, 2], ['Definição da equipe de Marketing', 1, 2], ['Ajustes nas páginas das redes sociais', 2, 2], ['Ações de arrecadação de fundos', 2, 4], ['Divulgação dos eventos de arrecadação', 2, 4], ['Divulgação dos resultados parciais', 3, 4], ['Participação na regional do TBR', 6, 1, 1]];
const GANTT_TE = [['Definição dos membros e discussão do Desafio Prático', 0, 2], ['Montagem do robô físico', 1, 2], ['Estratégia para o Desafio Prático', 1, 3], ['Programação para o tapete físico', 2, 4], ['Escrita parcial do caderno do projeto', 2, 4], ['Divulgação do caderno nas redes', 5, 2], ['Participação na Etapa Regional', 6, 1, 1]];
let GUT = [['Primeira reunião para definir funções', 5, 5, 5], ['Ajustes nas páginas das redes sociais', 3, 4, 4], ['Postagens nas redes sociais (1ª fase)', 3, 4, 4], ['Venda de doces em prol da equipe', 2, 3, 3], ['Bingo em prol das equipes de robótica', 4, 4, 4], ['Postagens nas redes sociais (2ª fase)', 3, 3, 4], ['Entrevista com especialista', 5, 5, 4], ['Término dos documentos da regional', 5, 5, 4]].map((r, i) => ({ id: 'g' + i, a: r[0], g: r[1], u: r[2], t: r[3], s: r[1] * r[2] * r[3] }));
const RISKS = [{ n: 'Falta de recursos financeiros', p: 3, i: 4, m: 'Busca ativa de patrocinadores e novas ações de arrecadação' }, { n: 'Desligamento de membros', p: 3, i: 4, m: 'Documentar atividades para facilitar transições' }, { n: 'Problemas técnicos', p: 3, i: 4, m: 'Manutenção preventiva e planos de contingência' }, { n: 'Fatores externos', p: 2, i: 4, m: 'Acompanhamento dos comunicados e flexibilidade' }, { n: 'Atrasos no cronograma', p: 3, i: 2, m: 'Empregar a Matriz GUT e acompanhar no Trello' }, { n: 'Baixo engajamento em divulgações', p: 3, i: 2, m: 'Planejamento de conteúdo e calendário com novas campanhas' }];
const FIN = { rec: [['Rifas', 2125], ['Bingo', 1214], ['Fondue no copo', 782], ['Cadeia', 465], ['Caixa da robótica', 400.72], ['Correio elegante', 144]], desp: [['Viagem para a regional', 1650], ['Inscrição na regional', 1600], ['Tapete de missões 2026', 1350], ['Materiais gerais', 200], ['Bottons de divulgação', 100]] };

/* =====================================================================
   RENDERER / SCENE
   ===================================================================== */
const canvas = $('#gl');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.75));
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.08;
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
const scene = new THREE.Scene();
const pmrem = new THREE.PMREMGenerator(renderer);
scene.environment = pmrem.fromScene(new RoomEnvironment(), .04).texture;
const camera = new THREE.PerspectiveCamera(30, 1, .05, 200);
const hemi = new THREE.HemisphereLight(0xeaf2ff, 0x0b2452, .6); scene.add(hemi);
const key = new THREE.DirectionalLight(0xffffff, 2.5); key.position.set(5, 10, 6); key.castShadow = true;
key.shadow.mapSize.set(2048, 2048); Object.assign(key.shadow.camera, { left: -9, right: 9, top: 9, bottom: -9, near: 1, far: 30 }); key.shadow.bias = -.0004; key.shadow.normalBias = .02; scene.add(key);
const rim = new THREE.DirectionalLight(0x9fd8ff, 2.2); rim.position.set(-6, 4, -6); scene.add(rim);
const fill = new THREE.DirectionalLight(0xffe8d8, .5); fill.position.set(-4, 2, 6); scene.add(fill);
const shadowMat = new THREE.ShadowMaterial({ opacity: .28, color: 0x041030 });
const ground = new THREE.Mesh(new THREE.PlaneGeometry(80, 80), shadowMat); ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);

/* =====================================================================
   MATERIALS — LEGO EV3 palette of the team's real robot (light grey, dark grey, red, white)
   ===================================================================== */
const pl = (color, o = {}) => new THREE.MeshPhysicalMaterial({ color, roughness: .38, metalness: 0, clearcoat: .3, clearcoatRoughness: .4, ...o });
const MAT = {
  white: pl(0xf2f3f1), lgrey: pl(0xa7adb3), dgrey: pl(0x41464d, { roughness: .45 }), black: pl(0x17191d, { roughness: .55, clearcoat: .1 }),
  red: pl(0xc8302a), teal: pl(0x5ed3d9, { roughness: .32 }), rubber: new THREE.MeshStandardMaterial({ color: 0x111215, roughness: .92 }),
  steel: new THREE.MeshStandardMaterial({ color: 0xdde1e6, metalness: 1, roughness: .12 }), hole: new THREE.MeshStandardMaterial({ color: 0x07080a, roughness: 1 }),
  led: new THREE.MeshStandardMaterial({ color: 0x2a2f36, emissive: 0x38d39a, emissiveIntensity: 0 }),
  eye: new THREE.MeshStandardMaterial({ color: 0x220a06, emissive: 0xff5a36, emissiveIntensity: .3 }),
  lens: new THREE.MeshPhysicalMaterial({ color: 0x050608, roughness: .05, clearcoat: 1 }),
  sensorLed: new THREE.MeshBasicMaterial({ color: 0xff3b2a, toneMapped: false }),
};
const RB = (w, h, d, r = .04) => new RoundedBoxGeometry(w, h, d, 3, Math.min(r, w / 2 - .001, h / 2 - .001, d / 2 - .001));
function add(geo, mat, parent, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0) { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.rotation.set(rx, ry, rz); m.castShadow = true; m.receiveShadow = true; parent.add(m); return m }
const STUD = .175;
function beam(parent, n, mat, x, y, z, along = 'z', holeAxis = 'x') {
  const g = new THREE.Group(); g.position.set(x, y, z); parent.add(g);
  const L = n * STUD, T = .15, Hh = .17;
  const dims = { x: [L, Hh, T], z: [T, Hh, L], y: [T, L, Hh] }[along];
  add(RB(...dims, .075), mat, g);
  const len = (holeAxis === 'x' ? dims[0] : holeAxis === 'y' ? dims[1] : dims[2]) + .012;
  const im = new THREE.InstancedMesh(new THREE.CylinderGeometry(.052, .052, len, 12), MAT.hole, n); const o = new THREE.Object3D();
  for (let i = 0; i < n; i++) { const t = -L / 2 + STUD / 2 + i * STUD; o.position.set(along === 'x' ? t : 0, along === 'y' ? t : 0, along === 'z' ? t : 0); o.rotation.set(holeAxis === 'z' ? Math.PI / 2 : 0, 0, holeAxis === 'x' ? Math.PI / 2 : 0); o.updateMatrix(); im.setMatrixAt(i, o.matrix) }
  g.add(im); return g;
}
const V = (x, y, z) => new THREE.Vector3(x, y, z);

/* =====================================================================
   ROBOT
   ===================================================================== */
const rig = new THREE.Group(); scene.add(rig);         // world placement (scale for the mat)
const robot = new THREE.Group(); rig.add(robot);       // yaw + parts
const PARTS = [];
function part(name, sub, home, off, labelOff, delay = 0, twist = 0, label = true) {
  const g = new THREE.Group(); g.position.copy(home); robot.add(g);
  const p = { name, sub, g, home: home.clone(), off: off.clone().multiplyScalar(.74), labelOff: labelOff || V(0, .3, 0), delay, twist, hl: 0, label };
  PARTS.push(p); return p;
}
// chassis
const chassis = part('Chassi', 'compacto e rígido', V(0, 0, 0), V(0, -.12, 0), V(.45, .7, -.2), 0);
beam(chassis.g, 15, MAT.lgrey, -.3, .5, -.05, 'z', 'x'); beam(chassis.g, 15, MAT.lgrey, .3, .5, -.05, 'z', 'x');
beam(chassis.g, 7, MAT.dgrey, 0, .5, -1.05, 'x', 'z'); beam(chassis.g, 7, MAT.dgrey, 0, .5, .95, 'x', 'z');
[[-.3, -.75], [.3, -.75], [-.3, .62], [.3, .62]].forEach(([x, z]) => beam(chassis.g, 3, MAT.lgrey, x, .82, z, 'y', 'x'));
const pinGeo = new THREE.CylinderGeometry(.045, .045, .22, 10);
[[-.3, -1.05], [.3, -1.05], [-.3, .95], [.3, .95], [-.3, .2], [.3, .2]].forEach(([x, z]) => add(pinGeo, MAT.red, chassis.g, x, .5, z, 0, 0, Math.PI / 2));
// large motors
function largeMotor(side) {
  const p = part('Motores grandes ×2', 'locomoção pelas linhas e cores', V(side * .62, .62, 0), V(side * 1.35, .35, 0), V(side * .1, .5, -.4), .08, side * .25, side < 0);
  const g = p.g;
  add(RB(.44, .5, 1.12, .14), MAT.white, g, 0, .02, -.18);
  add(new THREE.CylinderGeometry(.25, .25, .36, 28), MAT.lgrey, g, 0, .02, -.86, Math.PI / 2);
  add(RB(.46, .66, .52, .1), MAT.dgrey, g, 0, -.03, .5);
  add(new THREE.CylinderGeometry(.17, .17, .08, 28), MAT.red, g, side * .25, 0, .5, 0, 0, Math.PI / 2);
  add(RB(.452, .06, .9, .02), MAT.lgrey, g, 0, .26, -.18);
  add(new THREE.CylinderGeometry(.04, .04, .4, 8), MAT.lgrey, g, side * .4, 0, .5, 0, 0, Math.PI / 2);
  return p;
}
largeMotor(-1); largeMotor(1);
// wheels
const WR = .62;
const prof = []; { const r0 = .43, r1 = WR, w = .17, n = 10; prof.push(new THREE.Vector2(r0, -w)); for (let i = 0; i <= n; i++) { const a = -Math.PI / 2 + i / n * Math.PI; prof.push(new THREE.Vector2(r1 - .07 + Math.cos(a) * .07, Math.sin(a) * w)) } prof.push(new THREE.Vector2(r0, w)) }
const tireGeo = new THREE.LatheGeometry(prof, 64);
const wheels = [];
function wheel(side) {
  const p = part('Rodas', 'precisão sem perder velocidade', V(side * 1.02, .62, .5), V(side * 2.5, .25, .4), V(side * .3, .75, 0), .16, side * .6, side < 0);
  const spin = new THREE.Group(); p.g.add(spin); wheels.push(spin);
  add(tireGeo, MAT.rubber, spin, 0, 0, 0, 0, 0, Math.PI / 2);
  const tread = new THREE.InstancedMesh(new THREE.BoxGeometry(.3, .045, .07), MAT.rubber, 36); const o = new THREE.Object3D();
  for (let i = 0; i < 36; i++) { const a = i / 36 * Math.PI * 2; o.position.set(0, Math.cos(a) * (WR + .005), Math.sin(a) * (WR + .005)); o.rotation.set(a, 0, 0); o.updateMatrix(); tread.setMatrixAt(i, o.matrix) }
  tread.castShadow = true; spin.add(tread);
  add(new THREE.CylinderGeometry(.43, .43, .3, 40), MAT.lgrey, spin, 0, 0, 0, 0, 0, Math.PI / 2);
  add(new THREE.CylinderGeometry(.34, .34, .32, 40), MAT.lgrey, spin, 0, 0, 0, 0, 0, Math.PI / 2);
  const holes = new THREE.InstancedMesh(new THREE.CylinderGeometry(.06, .06, .34, 12), MAT.hole, 6);
  for (let i = 0; i < 6; i++) { const a = i / 6 * Math.PI * 2; o.position.set(0, Math.cos(a) * .2, Math.sin(a) * .2); o.rotation.set(0, 0, Math.PI / 2); o.updateMatrix(); holes.setMatrixAt(i, o.matrix) }
  spin.add(holes);
  add(new THREE.CylinderGeometry(.08, .08, .36, 16), MAT.red, spin, 0, 0, 0, 0, 0, Math.PI / 2);
  return p;
}
wheel(-1); wheel(1);
// EV3 brick
const brick = part('Hub EV3', 'posição definida no projeto', V(0, 1.27, -.15), V(0, 2.1, -.25), V(-.75, .45, -.3), .02);
{
  const g = brick.g;
  add(RB(1.22, .5, 1.86, .12), MAT.white, g); add(RB(1.25, .13, 1.89, .05), MAT.lgrey, g, 0, -.2, 0); add(RB(1.08, .04, 1.7, .02), MAT.dgrey, g, 0, .25, 0);
  add(RB(.86, .02, .62, .01), MAT.black, g, 0, .265, -.38);
  for (let i = 0; i < 4; i++) { add(new THREE.BoxGeometry(.17, .12, .04), MAT.black, g, -.42 + i * .28, -.02, .935); add(new THREE.BoxGeometry(.17, .12, .04), MAT.black, g, -.42 + i * .28, -.02, -.935) }
  add(RB(.2, .06, .2, .03), MAT.dgrey, g, 0, .28, .42);
  [[.24, 0], [-.24, 0], [0, .24], [0, -.24]].forEach(([x, z]) => add(RB(.17, .045, .17, .03), MAT.lgrey, g, x, .275, .42 + z));
  [[0, .05], [0, .79]].forEach(([x, z]) => add(new THREE.BoxGeometry(.62, .02, .03), MAT.led, g, x, .272, z));
  [[-.37, .42], [.37, .42]].forEach(([x, z]) => add(new THREE.BoxGeometry(.03, .02, .62), MAT.led, g, x, .272, z));
}
const scr = document.createElement('canvas'); scr.width = 512; scr.height = 352; const sx = scr.getContext('2d');
const scrTex = new THREE.CanvasTexture(scr); scrTex.colorSpace = THREE.SRGBColorSpace;
const screen = new THREE.Mesh(new THREE.PlaneGeometry(.78, .53), new THREE.MeshBasicMaterial({ map: scrTex, toneMapped: false })); screen.rotation.x = -Math.PI / 2; screen.position.set(0, .278, -.38); brick.g.add(screen);
const logoTex = new THREE.TextureLoader().load('img/logo.png'); logoTex.colorSpace = THREE.SRGBColorSpace;
[-1, 1].forEach(s => { const m = add(new THREE.CircleGeometry(.19, 48), new THREE.MeshStandardMaterial({ map: logoTex, roughness: .35 }), brick.g, s * .616, .02, .1, 0, s * Math.PI / 2); m.castShadow = false });
// medium motors (drive the claws)
function medMotor(side) {
  const p = part('Motores médios ×2', 'acionam as garras', V(side * .42, 1.72, -.55), V(side * 1.1, 1.9, -.6), V(side * .1, .3, 0), .2, side * .7, side < 0);
  const g = p.g;
  add(RB(.36, .3, .62, .09), MAT.white, g); add(RB(.37, .1, .63, .03), MAT.dgrey, g, 0, -.13, 0);
  add(new THREE.CylinderGeometry(.1, .1, .08, 24), MAT.red, g, 0, .02, .34, Math.PI / 2);
  add(new THREE.CylinderGeometry(.035, .035, 1.7, 8), MAT.lgrey, g, 0, .02, 1.2, Math.PI / 2);
  return p;
}
medMotor(-1); medMotor(1);
// color sensors ×3
const colorParts = [];
function colorSensor(x, z, lbl) {
  const p = part('Sensores de cor ×3', 'dois na frente seguem a linha', V(x, .3, z), V(x * 1.4, -.05, z + (z > 0 ? 1.2 : -1)), V(-.45, .05, 0), .14, 0, lbl);
  const g = p.g; add(RB(.28, .26, .34, .06), MAT.black, g); add(RB(.29, .1, .35, .03), MAT.white, g, 0, .1, 0);
  const d = add(new THREE.CircleGeometry(.06, 24), MAT.sensorLed, g, 0, -.132, .02, Math.PI / 2); d.castShadow = false;
  beam(g, 3, MAT.dgrey, 0, .25, -.1, 'y', 'x'); colorParts.push(p); return p;
}
colorSensor(-.26, 1.18, true); colorSensor(.26, 1.18, false); colorSensor(-.62, -1.05, false);
const beamMat = new THREE.MeshBasicMaterial({ color: 0xff4a2a, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false });
colorParts.forEach(p => { const c = new THREE.Mesh(new THREE.ConeGeometry(.14, .3, 24, 1, true), beamMat); c.position.set(0, -.28, .02); p.g.add(c) });
// caster
const caster = part('Rodízio', 'apoio traseiro', V(.3, .2, -1.25), V(.3, -.05, -2.1), V(.35, .15, 0), .12);
{ const g = caster.g; add(RB(.36, .2, .36, .06), MAT.black, g, 0, .1, 0); add(new THREE.SphereGeometry(.13, 32, 20), MAT.steel, g, 0, -.07, 0); }
// quick-coupling front mount (engate rápido)
const engate = part('Engate rápido', 'troca das 5 garras', V(0, .9, 1.38), V(0, .5, 2.2), V(.6, .2, 0), .18);
{ const g = engate.g; beam(g, 5, MAT.dgrey, -.5, 0, 0, 'y', 'z'); beam(g, 5, MAT.dgrey, .5, 0, 0, 'y', 'z'); beam(g, 7, MAT.lgrey, 0, .38, 0, 'x', 'z');
  [-.38, .38].forEach(x => add(new THREE.CylinderGeometry(.06, .06, .2, 12), MAT.red, g, x, .38, .12, Math.PI / 2)); }
const cableMat = new THREE.MeshStandardMaterial({ color: 0x0d0e10, roughness: .5, transparent: true });
const cableGroup = new THREE.Group(); robot.add(cableGroup);
[[[-.42, 1.25, .81], [-.55, 1.3, 1.0], [-.62, 1.0, .9], [-.62, .95, .62]], [[.42, 1.25, .81], [.55, 1.3, 1.0], [.62, 1.0, .9], [.62, .95, .62]], [[-.14, 1.25, .81], [-.2, 1.2, 1.1], [-.26, .7, 1.22], [-.26, .45, 1.18]], [[.14, 1.25, .81], [.2, 1.2, 1.1], [.26, .7, 1.22], [.26, .45, 1.18]], [[-.42, 1.25, -1.1], [-.45, 1.65, -1.0], [-.42, 1.75, -.85]], [[.42, 1.25, -1.1], [.45, 1.65, -1.0], [.42, 1.75, -.85]]]
  .forEach(pts => add(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts.map(p => V(...p))), 40, .028, 8), cableMat, cableGroup));
const hitProxy = new THREE.Mesh(new THREE.BoxGeometry(2.6, 2.4, 3.6), new THREE.MeshBasicMaterial({ visible: false })); hitProxy.position.set(0, 1.1, .2); robot.add(hitProxy);

/* ---------- the 5 garras (attach to the quick-coupling mount) ---------- */
const MOUNT = V(0, .95, 1.5);
const GARRA_G = [];
function garraGroup(build) { const g = new THREE.Group(); g.position.copy(MOUNT); robot.add(g); build(g); g.visible = false; GARRA_G.push(g); return g }
garraGroup(g => { // 1 · portal collector
  beam(g, 9, MAT.teal, 0, -.55, .55, 'x', 'z'); beam(g, 7, MAT.teal, -.7, -.55, .9, 'z', 'x'); beam(g, 7, MAT.teal, .7, -.55, .9, 'z', 'x');
  beam(g, 9, MAT.lgrey, -.7, .1, 1.45, 'y', 'x'); beam(g, 9, MAT.lgrey, .7, .1, 1.45, 'y', 'x'); beam(g, 9, MAT.lgrey, 0, .82, 1.45, 'x', 'z');
  beam(g, 7, MAT.lgrey, -.7, .82, .9, 'z', 'x'); beam(g, 7, MAT.lgrey, .7, .82, .9, 'z', 'x');
  add(RB(.5, .08, .4, .03), MAT.dgrey, g, .3, -.62, 1.55, 0, 0, 0);
});
garraGroup(g => { // 2 · comb plates + L arm
  [-.5, 0, .5].forEach(x => add(RB(.42, .08, .9, .03), MAT.dgrey, g, x - .15, -.05, .75));
  beam(g, 9, MAT.teal, -.15, -.18, .45, 'x', 'z');
  beam(g, 7, MAT.lgrey, .85, .45, .55, 'y', 'x'); beam(g, 5, MAT.lgrey, .85, 1.0, .9, 'z', 'x');
  beam(g, 5, MAT.lgrey, -.75, -.45, .6, 'y', 'x'); add(RB(.6, .08, .1, .03), MAT.black, g, -.55, -.85, .62);
  add(new THREE.CylinderGeometry(.04, .04, .3, 10), MAT.black, g, 0, .12, .7);
});
garraGroup(g => { // 3 · passive fixed loop frame (white)
  beam(g, 11, MAT.white, 0, -.55, 1.75, 'x', 'z'); beam(g, 9, MAT.white, -.95, -.55, 1.0, 'z', 'x'); beam(g, 9, MAT.white, .95, -.55, 1.0, 'z', 'x');
  beam(g, 5, MAT.white, -.55, -.55, .28, 'x', 'z'); beam(g, 5, MAT.white, .55, -.55, .28, 'x', 'z');
  beam(g, 3, MAT.dgrey, -.2, -.25, .35, 'y', 'x'); beam(g, 3, MAT.dgrey, .2, -.25, .35, 'y', 'x');
});
let maker = null;
garraGroup(g => { // 4 · modular + ultrasonic
  add(RB(1.9, .1, .5, .04), MAT.white, g, 0, .05, .5);
  [-.8, .8].forEach(x => add(RB(.25, .3, .5, .05), MAT.white, g, x, .2, .5));
  beam(g, 9, MAT.teal, 0, -.35, 1.05, 'x', 'z'); beam(g, 5, MAT.teal, -.7, -.35, .7, 'z', 'x'); beam(g, 5, MAT.teal, .7, -.35, .7, 'z', 'x');
  const u = new THREE.Group(); u.position.set(0, .35, .55); g.add(u); maker = u;
  add(RB(.8, .26, .26, .09), MAT.white, u);
  [-.2, .2].forEach(x => { add(new THREE.CylinderGeometry(.1, .1, .12, 28), MAT.black, u, x, .01, .13, Math.PI / 2); add(new THREE.CircleGeometry(.075, 28), MAT.lens, u, x, .01, .195); add(new THREE.TorusGeometry(.088, .014, 8, 32), MAT.eye, u, x, .01, .196) });
});
garraGroup(g => { // 5 · two L pushers with red tips
  [-.55, .55].forEach(x => { beam(g, 7, MAT.white, x, .25, .45, 'y', 'x'); beam(g, 5, MAT.dgrey, x, -.38, .85, 'z', 'x'); add(new THREE.CylinderGeometry(.06, .06, .24, 12), MAT.red, g, x, -.38, 1.35, 0, 0, Math.PI / 2); add(new THREE.CylinderGeometry(.06, .06, .24, 12), MAT.red, g, x, -.38, 1.05, 0, 0, Math.PI / 2) });
  beam(g, 7, MAT.lgrey, 0, -.38, .45, 'x', 'z');
});
const ultraScan = new THREE.Mesh(new THREE.ConeGeometry(.9, 3.4, 40, 1, true), new THREE.MeshBasicMaterial({ color: 0x7fd3ff, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }));
ultraScan.rotation.x = -Math.PI / 2; ultraScan.position.set(0, 0, 1.9); maker.add(ultraScan);

/* =====================================================================
   THE OFFICIAL MAT + 5 SAÍDAS
   ===================================================================== */
const MW = 12.4, MD = 12.4 / 2.147;
const uvToXZ = ([u, v]) => V((u - .5) * MW, 0, (v - .5) * MD);
const matGroup = new THREE.Group(); scene.add(matGroup);
const matMats = [];
{
  const tex = new THREE.TextureLoader().load('img/tapete.jpg'); tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = renderer.capabilities.getMaxAnisotropy();
  const m = new THREE.MeshStandardMaterial({ map: tex, roughness: .9, transparent: true, opacity: 0 }); matMats.push(m);
  const plane = new THREE.Mesh(new THREE.PlaneGeometry(MW, MD), m); plane.rotation.x = -Math.PI / 2; plane.position.y = .003; plane.receiveShadow = true; matGroup.add(plane);
  const bm = new THREE.MeshStandardMaterial({ color: 0x0b2452, roughness: .7, transparent: true, opacity: 0 }); matMats.push(bm);
  [[0, -MD / 2 - .15, MW + .6, .3], [0, MD / 2 + .15, MW + .6, .3]].forEach(([bx, bz, w, d]) => add(new THREE.BoxGeometry(w, .35, d), bm, matGroup, bx, .175, bz));
  [[-MW / 2 - .15, 0], [MW / 2 + .15, 0]].forEach(([bx, bz]) => add(new THREE.BoxGeometry(.3, .35, MD), bm, matGroup, bx, .175, bz));
}
const SCURVES = SAIDAS.map(s => new THREE.CatmullRomCurve3(s.pts.map(uvToXZ), false, 'centripetal', .5));
const trails = SCURVES.map(c => { const geo = new THREE.TubeGeometry(c, 300, .045, 8); const m = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ color: 0x7fd3ff, toneMapped: false, transparent: true, opacity: 0 })); m.position.y = .05; m.userData.total = geo.index.count; matGroup.add(m); return m });
// checkpoint params: nearest u on the curve to the control point
const CPS = [];
SAIDAS.forEach((s, si) => s.cps.forEach(([ci, tag, name, pts, sec]) => {
  const target = uvToXZ(s.pts[ci]); let best = 0, bd = 1e9;
  for (let i = 0; i <= 400; i++) { const d = SCURVES[si].getPointAt(i / 400).distanceTo(target); if (d < bd) { bd = d; best = i / 400 } }
  CPS.push({ si, u: best, tag, name, pts, sec, pos: SCURVES[si].getPointAt(best) });
}));
// mission pins
const pinMat = new THREE.MeshBasicMaterial({ color: 0x7fd3ff, toneMapped: false, transparent: true, opacity: 0 });
CPS.forEach(c => { const r = new THREE.Mesh(new THREE.RingGeometry(.22, .3, 40), pinMat.clone()); r.rotation.x = -Math.PI / 2; r.position.copy(c.pos).setY(.02); matGroup.add(r); c.ring = r });
// PID line (straight black line across the middle of the mat)
const PID_Z = (.53 - .5) * MD, PID_X0 = -3.6, PID_X1 = 3.0;

/* =====================================================================
   DOM: part labels + mission checkpoints
   ===================================================================== */
const labelsEl = $('#labels');
PARTS.forEach(p => {
  if (!p.label) return;
  const el = document.createElement('div'); el.className = 'plabel'; el.innerHTML = `<i></i><div><b>${p.name}</b><span>${p.sub}</span></div>`;
  const sibs = PARTS.filter(q => q.name === p.name);
  el.addEventListener('pointerenter', () => sibs.forEach(q => gsap.to(q, { hl: 1, duration: .4 })));
  el.addEventListener('pointerleave', () => sibs.forEach(q => gsap.to(q, { hl: 0, duration: .6 })));
  labelsEl.append(el); p.el = el;
});
CPS.forEach(c => { const el = document.createElement('div'); el.className = 'cp'; el.innerHTML = `<div class="pin"></div><div class="card"><em>${c.tag}${c.pts ? ` · +${c.pts} pts · ${c.sec}s` : ''}</em><b>${c.name}</b></div>`; labelsEl.append(el); c.el = el });

/* =====================================================================
   STATE + GSAP MASTER TIMELINE
   ===================================================================== */
const S = { cx: 5.0, cy: 2.3, cz: 6.4, tx: 0, ty: .85, tz: 0, yaw: -.75, ex: 0, mat: 0, onS: 0, D: 0, onPid: 0, pid: 0, garra: 0, zoff: 0, dark: 0, follow: 0, rs: 1, scan: 0 };
const master = gsap.timeline({ paused: true, defaults: { ease: 'power2.inOut' } });
const SEG = {};
const seg = (name, list) => { const st = master.duration(); list.forEach(([d, p]) => master.to(S, { duration: d, ...p })); SEG[name] = [st, master.duration()] };
seg('hero', [[1, { cx: 3.0, cy: 3.3, cz: 6.9, tx: .35, ty: .9, yaw: .4 }]]);
seg('quem', [[1, { cx: -.4, cy: 1.8, cz: 7.8, tx: -1.6, ty: 1.0, tz: 0, yaw: 1.5 }]]);
seg('build', [
  [.8, { cx: 7.4, cy: 6.2, cz: 10.8, tx: 1.0, ty: 2.0, tz: 0, yaw: -.55, ex: 1 }],
  [1.6, { cx: -5.6, cy: 5.6, cz: 10.8, yaw: .55, ease: 'sine.inOut' }],
  [.8, { ex: 0, cx: 4.6, cy: 3.0, cz: 6.8, tx: .4, ty: .95, yaw: -.3 }]]);
seg('garras', [
  [.6, { cx: 4.4, cy: 2.6, cz: 7.2, tx: -1.3, ty: 1.0, tz: .7, yaw: -.65, garra: 1 }],
  [.9, { garra: 2, yaw: -.35, cx: 3.8, cy: 2.9 }], [.9, { garra: 3, yaw: -.7, cy: 3.6, cz: 7.6 }], [.9, { garra: 4, yaw: -.4, cy: 2.4, cz: 6.8 }], [.9, { garra: 5, yaw: -.6, cy: 2.8, cz: 7.2 }], [.3, {}]]);
seg('saidas', [
  [.8, { dark: 1, mat: 1, onS: 1, rs: .48, cx: 0, cy: 15.8, cz: 6.4, tx: 0, ty: 0, tz: .45, ex: 0 }],
  [5, { D: 5, ease: 'none' }], [.3, {}]]);
seg('pid', [
  [.8, { onS: 0, onPid: 1, follow: 1, cx: -1.5, cy: .95, cz: 2.2, tx: .5, ty: .25, tz: 0 }],
  [2.4, { pid: 1, ease: 'none' }]]);
seg('cwb', [
  [1, { mat: 0, onPid: 0, follow: 0, rs: 1, dark: 1, yaw: 0, garra: 2, cx: 0, cy: .8, cz: 7.4, tx: 0, ty: 1.05, tz: 0 }],
  [2.2, { zoff: 5.4, cy: 1.7, cz: 9, ty: 1.25, ease: 'power1.in' }]]);
master.progress(1).progress(0);
const playhead = { t: 0 };

/* =====================================================================
   FRAME LOOP
   ===================================================================== */
let W = innerWidth, H = innerHeight, distF = 1;
function resize() { W = innerWidth; H = innerHeight; renderer.setSize(W, H, false); camera.aspect = W / H; camera.updateProjectionMatrix(); distF = camera.aspect < .8 ? 1.75 : camera.aspect < 1.2 ? 1.35 : 1 }
const mouse = { nx: 0, ny: 0 };
const user = { yaw: 0, explode: 0, power: 0, boot: 0 }, intro = { drop: 0, spin: 0 };
let renderOn = true, chapName = 'Início';
const tmp = new THREE.Vector3(), camPos = new THREE.Vector3(), tgt = new THREE.Vector3(), rPos = new THREE.Vector3(), prevPos = new THREE.Vector3(), fwd = new THREE.Vector3();
const clock = new THREE.Clock(); let lt = 0, roll = 0, hudCache = '';
const pidErr = p => .42 * Math.exp(-3.2 * p) * Math.sin(16 * p + .4);

function drawScreen(t) {
  const on = user.power, b = user.boot;
  sx.fillStyle = on > .01 ? '#c5d1c0' : '#3c443e'; sx.fillRect(0, 0, 512, 352);
  if (on > .01) {
    sx.globalAlpha = on; sx.fillStyle = '#122016';
    if (b < 1) { sx.font = '900 64px Arial Black, Arial'; sx.textAlign = 'center'; sx.fillText('GTEeN', 256, 160); sx.fillRect(116, 210, 280 * b, 18); sx.strokeStyle = '#122016'; sx.lineWidth = 3; sx.strokeRect(116, 210, 280, 18); sx.font = '600 22px monospace'; sx.fillText('INICIANDO', 256, 270) }
    else {
      sx.textAlign = 'left'; sx.fillRect(0, 0, 512, 46); sx.fillStyle = '#c5d1c0'; sx.font = '700 24px monospace'; sx.fillText('GTEeN · EV3', 14, 31);
      sx.fillStyle = '#122016'; sx.font = '800 38px Arial Black, Arial'; sx.fillText(chapName.toUpperCase().slice(0, 17), 18, 110);
      sx.font = '600 20px monospace'; sx.fillText(S.onPid > .5 ? 'PID · ERRO ' + pidErr(S.pid).toFixed(2) : S.onS > .5 ? 'SAIDA ' + Math.min(5, Math.floor(S.D) + 1) + ' · GARRA ' + Math.min(5, Math.floor(S.D) + 1) : 'SENSOR · COR', 18, 158);
      sx.lineWidth = 4; sx.strokeStyle = '#122016'; sx.beginPath();
      for (let i = 0; i <= 120; i++) { const xx = 18 + i * 3.9, yy = 255 + Math.sin(i * .18 + t * 4) * 28 * Math.sin(t * .7 + i * .03); i ? sx.lineTo(xx, yy) : sx.moveTo(xx, yy) } sx.stroke();
    }
    sx.globalAlpha = 1;
  }
  scrTex.needsUpdate = true;
}

function frame() {
  requestAnimationFrame(frame);
  const t = clock.getElapsedTime(), dt = Math.min(.5, t - lt); lt = t;
  master.time(master.time() + (playhead.t - master.time()) * (RM ? 1 : 1 - Math.exp(-dt * 6)));
  if (!renderOn) return;

  // ---- robot placement: free / on the 5 saídas / on the PID line
  let yaw = S.yaw; rPos.set(0, 0, 0); let lift = 0, gVal = S.garra;
  if (S.onS > 0) {
    const D = clamp(S.D, 0, 4.9999), i = Math.floor(D), f = D - i;
    const hop = .1, u = clamp((f - hop) / (1 - hop));
    const c = SCURVES[i], p = c.getPointAt(u), tn = c.getTangentAt(Math.max(.001, Math.min(.999, u)));
    let sp = p.clone(), sy = Math.atan2(tn.x, tn.z);
    if (f < hop && i > 0) { // robot is lifted from the end of the previous saída back to the base
      const k = easeIO(f / hop), prevEnd = SCURVES[i - 1].getPointAt(1), prevTan = SCURVES[i - 1].getTangentAt(.999);
      sp = prevEnd.clone().lerp(p, k); lift = Math.sin(k * Math.PI) * 1.4; sy = lerpAng(Math.atan2(prevTan.x, prevTan.z), sy, k);
    }
    rPos.lerp(sp, S.onS); yaw = lerpAng(yaw, sy, S.onS);
    gVal = THREE.MathUtils.lerp(S.garra, i + Math.min(1, f / hop), S.onS);
  }
  if (S.onPid > 0) {
    const x = THREE.MathUtils.lerp(PID_X0, PID_X1, S.pid), e = pidErr(S.pid), de = (pidErr(S.pid + .002) - e) / (.002 * (PID_X1 - PID_X0));
    rPos.lerp(tmp.set(x, 0, PID_Z + e), S.onPid); yaw = lerpAng(yaw, Math.PI / 2 - Math.atan(de), S.onPid);
  }
  rPos.z += S.zoff; rPos.y += lift + intro.drop;
  rig.position.copy(rPos); rig.scale.setScalar(S.rs);
  robot.rotation.y = yaw + user.yaw + intro.spin;
  // wheels roll from real displacement along the robot's forward axis
  fwd.set(Math.sin(robot.rotation.y), 0, Math.cos(robot.rotation.y));
  roll += tmp.copy(rPos).sub(prevPos).dot(fwd) / (WR * S.rs); prevPos.copy(rPos);
  wheels.forEach(w => w.rotation.x = roll);

  // ---- explode
  const ex = Math.max(S.ex, user.explode);
  PARTS.forEach(p => { const e = easeIO(clamp((ex - p.delay) / (1 - .26))); p.g.position.copy(p.home).addScaledVector(p.off, e); p.g.position.y += Math.sin(t * 1.2 + p.delay * 20) * .04 * e; p.g.rotation.y = p.twist * e + p.hl * .4; p.g.scale.setScalar(1 + p.hl * .1) });
  cableMat.opacity = 1 - clamp(ex * 2.5); cableGroup.visible = cableMat.opacity > .02;

  // ---- garras: attached amount from distance to gVal; incoming from above, outgoing forward-down
  GARRA_G.forEach((g, i) => {
    const d = gVal - (i + 1), a = clamp(1 - Math.abs(d) * 1.6);
    g.visible = a > .01 && ex < .5;
    if (!g.visible) return;
    const away = 1 - easeIO(a);
    g.position.copy(MOUNT).add(d < 0 ? tmp.set(0, 2.4 * away, .4 * away) : tmp.set(0, -.6 * away, 2.2 * away));
    g.rotation.x = (d < 0 ? -.6 : .5) * away; g.scale.setScalar(.4 + .6 * easeIO(a));
  });
  ultraScan.material.opacity = (Math.abs(gVal - 4) < .3 ? 1 : 0) * (.08 + Math.sin(t * 6) * .03) * user.power;

  // ---- lights / screen
  const pw = user.power;
  MAT.led.emissiveIntensity = pw * (1.6 + Math.sin(t * 3) * .4);
  MAT.eye.emissiveIntensity = .3 + pw * 1.4;
  beamMat.opacity = pw * (.45 + S.onPid * .35);
  if ((t * 20 | 0) % 2 === 0) drawScreen(t);
  key.intensity = 2.5 - S.dark * 1.0; rim.intensity = 2.2 + S.dark * 4; hemi.intensity = .6 - S.dark * .25;
  shadowMat.opacity = .28 * (1 - S.dark);
  matMats.forEach(m => m.opacity = S.mat); matGroup.visible = S.mat > .01;

  const Dn = S.D;
  trails.forEach((tr, i) => { const prog = S.onS > .5 ? clamp(Dn - i - .1) / .9 : 0; tr.material.opacity = S.mat * (Dn > i ? (Math.floor(Dn) === i ? 1 : .28) : 0); tr.geometry.setDrawRange(0, Math.floor(tr.userData.total * clamp(prog) / 48) * 48) });

  // ---- camera
  camPos.set(S.cx, S.cy, S.cz); tgt.set(S.tx, S.ty, S.tz);
  let follow = S.follow;
  if (W < 760 && S.onS > 0 && S.onPid < .5) { follow = Math.max(follow, S.onS); camPos.lerp(tmp.set(0, 7.2, 5.0), S.onS); tgt.lerp(tmp.set(0, 0, 0), S.onS) }
  if (follow > 0) { camPos.lerp(tmp.copy(rPos).setY(0).add(camPos), follow); tgt.lerp(tmp.copy(rPos).setY(0).add(tgt), follow) }
  camPos.sub(tgt).multiplyScalar(follow > .5 ? 1 : distF).add(tgt);
  camPos.x += mouse.nx * .3 + Math.sin(t * .35) * .06; camPos.y += mouse.ny * .2 + Math.cos(t * .3) * .04;
  camera.position.copy(camPos); camera.lookAt(tgt);
  renderer.render(scene, camera);

  // ---- labels
  const showL = ex > .55;
  PARTS.forEach(p => { if (!p.el) return; tmp.copy(p.labelOff).applyMatrix4(p.g.matrixWorld).project(camera); const x = (tmp.x * .5 + .5) * W, y = (-tmp.y * .5 + .5) * H; p.el.style.transform = `translate(${x.toFixed(1)}px,${y.toFixed(1)}px)`; p.el.style.opacity = showL && tmp.z < 1 ? 1 : 0; p.el.style.pointerEvents = showL ? 'auto' : 'none' });
  // ---- mission checkpoints + HUD
  let pts = 0, sec = 0; const Di = Math.floor(clamp(Dn, 0, 4.9999)), uNow = clamp((Dn - Di - .1) / .9);
  CPS.forEach(c => {
    const done = S.onS > .5 && (Dn >= 5 || c.si < Di || (c.si === Di && uNow >= c.u - .003)); if (done) { pts += c.pts; sec += c.sec }
    const vis = S.onS > .6 && S.mat > .6 && c.si <= Di;
    c.ring.material.opacity = S.mat * S.onS * (c.si === Di ? (.6 + Math.sin(t * 4) * .3) : c.si < Di ? .25 : 0);
    tmp.copy(c.pos).applyMatrix4(matGroup.matrixWorld).project(camera); const x = (tmp.x * .5 + .5) * W, y = (-tmp.y * .5 + .5) * H;
    c.el.style.transform = `translate(${x.toFixed(1)}px,${y.toFixed(1)}px)`; c.el.style.opacity = vis ? 1 : 0;
    c.el.classList.toggle('on', done && (c.si === Di || Dn >= 5)); c.el.classList.toggle('left', x > W * .6);
  });
  if (S.onS > .5) {
    const key2 = Di + '|' + pts + '|' + sec;
    if (key2 !== hudCache) { hudCache = key2; $('#hS').textContent = Math.min(5, Di + 1); $('#hP').textContent = String(pts).padStart(3, '0'); $('#hT').textContent = String(sec).padStart(3, '0'); $('#hBar').style.width = pts / 5 + '%'; $('#sNum').textContent = `09 — Saída ${Di + 1} / 5 · Garra ${Di + 1}`; $('#sTitle').textContent = `Saída ${Di + 1}`; $('#sText').textContent = SAIDAS[Di].txt }
  }
  // ---- PID chart
  if (S.onPid > .3) {
    const n = Math.max(2, Math.floor(S.pid * 120)); let d = ''; for (let i = 0; i <= n; i++) { const p = i / 120; d += (i ? 'L' : 'M') + (p * 500).toFixed(1) + ' ' + (70 - pidErr(p) * 140).toFixed(1) }
    $('#pPath').setAttribute('d', d); $('#pDot').setAttribute('cx', S.pid * 500); $('#pDot').setAttribute('cy', 70 - pidErr(S.pid) * 140);
    $('#pErr').textContent = (pidErr(S.pid) >= 0 ? '+' : '') + pidErr(S.pid).toFixed(2).replace('.', ',');
  }
}

/* =====================================================================
   INTERACTION
   ===================================================================== */
const ray = new THREE.Raycaster();
const overRobot = (cx, cy) => { ray.setFromCamera({ x: cx / W * 2 - 1, y: -(cy / H * 2 - 1) }, camera); return ray.intersectObject(hitProxy, false).length > 0 };
let drag = null; const curL = $('.cur-l');
const canGrab = () => renderOn && S.mat < .5;
addEventListener('pointermove', e => {
  mouse.nx = e.clientX / W * 2 - 1; mouse.ny = -(e.clientY / H * 2 - 1);
  if (drag) { const dx = e.clientX - drag.x; drag.x = e.clientX; drag.v = dx * .01; user.yaw += drag.v; drag.m += Math.abs(dx); return }
  if (!TOUCH) { const inStory = !!document.elementFromPoint(e.clientX, e.clientY)?.closest('.chap'); const o = inStory && canGrab() && overRobot(e.clientX, e.clientY); curL.style.opacity = o ? 1 : 0; document.body.style.cursor = o ? 'grab' : '' }
}, { passive: true });
addEventListener('pointerdown', e => { if (!e.target.closest('.chap') || e.target.closest('a,button,input,.plabel,.panel')) return; if (!canGrab() || !overRobot(e.clientX, e.clientY)) return; drag = { x: e.clientX, v: 0, m: 0 }; gsap.killTweensOf(user, 'yaw'); lenis?.stop(); e.preventDefault() });
addEventListener('pointerup', () => { if (!drag) return; const d = drag; drag = null; lenis?.start(); if (d.m < 5) { togglePower(); return } gsap.to(user, { yaw: user.yaw + d.v * 22, duration: 1.2, ease: 'power3.out', onComplete: () => gsap.to(user, { yaw: Math.round(user.yaw / (Math.PI * 2)) * Math.PI * 2, duration: 1.6, ease: 'elastic.out(1,.55)' }) }) });
function togglePower(force) {
  const on = force ?? user.power < .5; const b = $('#powerBtn'); b.setAttribute('aria-pressed', on); b.lastElementChild.textContent = on ? 'Robô ligado' : 'Ligar o robô';
  if (on) { gsap.to(user, { power: 1, duration: .4 }); user.boot = 0; gsap.to(user, { boot: 1, duration: 1.6, ease: 'power1.inOut' }); toast('EV3 ligado · sensores de cor ativos') } else gsap.to(user, { power: 0, duration: .4 });
}
$('#powerBtn').addEventListener('click', () => togglePower());
$('#explodeBtn').addEventListener('click', e => { const on = user.explode < .5; e.currentTarget.setAttribute('aria-pressed', on); e.currentTarget.textContent = on ? 'Montar' : 'Desmontar'; gsap.to(user, { explode: on ? 1 : 0, duration: 1.6, ease: 'expo.inOut' }); if (on) toast('Passe o mouse nas etiquetas das peças') });

/* =====================================================================
   SCROLL
   ===================================================================== */
let lenis = null;
if (!RM && window.Lenis) { lenis = new Lenis({ lerp: .085 }); lenis.on('scroll', ScrollTrigger.update); gsap.ticker.add(t => lenis.raf(t * 1000)); gsap.ticker.lagSmoothing(0) }
const goto = id => { const el = document.getElementById(id); if (!el) return; const y = el.getBoundingClientRect().top + scrollY; lenis ? lenis.scrollTo(y, { duration: 1.8 }) : scrollTo({ top: y, behavior: RM ? 'auto' : 'smooth' }) };
document.addEventListener('click', e => { const a = e.target.closest('[data-goto]'); if (!a) return; e.preventDefault(); closeMenu(); goto(a.dataset.goto) });
const CHAPS = $$('.chap');
let gIdx = -1;
function setGarra(i) {
  if (i === gIdx) return; gIdx = i; const G = GARRAS[i];
  $$('#gDots button').forEach((b, j) => b.classList.toggle('on', j === i));
  gsap.timeline().to('.g-card .ph img, #gTitle, #gText, #gTags', { opacity: 0, y: -10, duration: .15 })
    .add(() => { $('#gImg').src = `img/garra-${i + 1}.webp`; $('#gImg').alt = `Render da garra ${i + 1}`; $('#gNum').textContent = `Garra ${i + 1} / 5 · Saída ${G.s}`; $('#gTitle').textContent = G.t; $('#gText').textContent = G.p; $('#gTags').innerHTML = G.tags.map(x => `<span>${x}</span>`).join('') })
    .to('.g-card .ph img, #gTitle, #gText, #gTags', { opacity: 1, y: 0, duration: .4, stagger: .04, ease: 'power3.out' });
}
$('#gDots').innerHTML = GARRAS.map((_, i) => `<button aria-label="Garra ${i + 1}">${i + 1}</button>`).join('');
$$('#gDots button').forEach((b, i) => b.onclick = () => { const st = ScrollTrigger.getById('st-garras'); if (!st) return; const p = (.6 + i * .9) / 4.5; const y = st.start + (st.end - st.start) * p; lenis ? lenis.scrollTo(y, { duration: 1.2 }) : scrollTo(0, y) });
function setupStory() {
  CHAPS.forEach(ch => {
    const [a, b] = SEG[ch.dataset.seg];
    ScrollTrigger.create({ id: 'st-' + ch.dataset.seg, trigger: ch, start: ch.id === 'c-hero' ? 'top top' : 'top bottom', end: 'bottom bottom',
      onUpdate: s => { playhead.t = a + (b - a) * s.progress; if (ch.dataset.seg === 'garras') setGarra(Math.min(4, Math.max(0, Math.round(((b - a) * s.progress - .6) / .9 + 1) - 1))) },
      onEnter: () => { if (ch.id !== 'c-hero' && user.power < .5) togglePower(true) } });
  });
  const vis = new Set();
  const io = new IntersectionObserver(es => { es.forEach(e => e.isIntersecting ? vis.add(e.target) : vis.delete(e.target)); renderOn = vis.size > 0; canvas.style.visibility = renderOn ? 'visible' : 'hidden'; labelsEl.style.visibility = renderOn ? 'visible' : 'hidden' }, { rootMargin: '10% 0px' });
  CHAPS.forEach(c => io.observe(c));
  gsap.to('#ghost', { scale: 1.25, yPercent: -12, opacity: 0, ease: 'none', scrollTrigger: { trigger: '#c-hero', start: 'top top', end: 'bottom bottom', scrub: true } });
  gsap.fromTo('#cwbWord', { scale: .55, opacity: 0 }, { scale: 1.15, opacity: 1, ease: 'none', scrollTrigger: { trigger: '#c-cwb', start: 'top 60%', end: 'bottom bottom', scrub: true } });
  gsap.from('#next4 > div', { y: 40, opacity: 0, stagger: .08, scrollTrigger: { trigger: '#c-cwb', start: '55% bottom', end: '80% bottom', scrub: true } });
}
setGarra(0);

/* =====================================================================
   EDITORIAL BLOCKS
   ===================================================================== */
function splitWords(el) { const walk = n => [...n.childNodes].forEach(c => { if (c.nodeType === 3) { const f = document.createDocumentFragment(); c.textContent.split(/(\s+)/).forEach(w => { if (!w) return; if (/^\s+$/.test(w)) { f.append(' '); return } const o = document.createElement('span'); o.className = 'w'; const i = document.createElement('span'); i.textContent = w; o.append(i); f.append(o) }); c.replaceWith(f) } else if (c.nodeType === 1 && c.tagName !== 'BR') walk(c) }); walk(el) }
$$('.split').forEach(splitWords); splitWords($('#decQ'));
// members
$('#memGrid').innerHTML = MEMBERS.map(([n, r, a, img]) => `<article class="mem" tabindex="0" data-a="${a.join(' ')}"><div class="tags">${a.map(x => `<i class="${x}">${x}</i>`).join('')}</div><div class="ph"><img src="img/${img}.jpg" alt="${n}" loading="lazy"></div><div class="cap"><b>${n}</b><span>${r}</span></div></article>`).join('');
$$('#time .filters button').forEach(b => b.onclick = () => { $$('#time .filters button').forEach(x => x.setAttribute('aria-pressed', x === b)); const f = b.dataset.f; $$('.mem').forEach(m => m.classList.toggle('dim', f !== 'all' && !m.dataset.a.split(' ').includes(f))) });
// history
$('#hzTrack').innerHTML = HIST.map(h => h.photo ? `<article class="hz-card photo"><img src="img/${h.photo}" alt="${h.alt}" loading="lazy"><p>${h.p}</p></article>` : `<article class="hz-card${h.hi ? ' hi' : ''}"><span class="yr${h.o ? ' o' : ''}">${h.y}</span><div><h3>${h.t}</h3><p style="margin-top:6px">${h.p}</p></div></article>`).join('');
// prizes
$('#ptable').innerHTML = PREMIOS.map(([y, a, c, e, p]) => `<div class="prow" data-e="${e}" data-p="${p}"><span class="y">${y}</span><span>${a} · ${c}</span><span class="st${e === 'Nacional' ? ' n' : ''}">${e}</span><span class="pl${p === 1 ? ' g' : ''}">${p}º</span></div>`).join('');
$$('#pFilter button').forEach(b => b.onclick = () => { $$('#pFilter button').forEach(x => x.setAttribute('aria-pressed', x === b)); const f = b.dataset.p; const st = Flip.getState('.prow'); $$('.prow').forEach(r => r.classList.toggle('hide', !(f === 'all' || r.dataset.e === f || (f === '1' && r.dataset.p === '1')))); Flip.from(st, { duration: .5, ease: 'power2.inOut', onEnter: e => gsap.fromTo(e, { opacity: 0 }, { opacity: 1 }), onLeave: e => gsap.to(e, { opacity: 0 }) }) });
// missions
$('#misGrid').innerHTML = MISSOES.map(([n, t, d, p]) => `<div class="cell-b"><span class="n">MISSÃO ${n}</span><span class="pts">${p}<small>pts máx.</small></span><b class="t" style="padding-right:70px">${t}</b><p>${d}</p></div>`).join('');
// programming tabs
$('#tabs').innerHTML = BLOCOS.map(([n], i) => `<button role="tab" aria-selected="${i === 0}" data-i="${i}">${n}</button>`).join('');
const showTab = i => { const [n, d, ex] = BLOCOS[i]; $$('#tabs button').forEach((b, j) => b.setAttribute('aria-selected', j === i)); $('#tabpanel').innerHTML = `<div><b class="big">${n}</b><p>${d}</p></div><div><span class="mono" style="color:var(--sky)">Exemplos</span><div class="ex">${ex.map(x => `<span>${x}</span>`).join('')}</div></div>`; gsap.from('#tabpanel > div', { y: 16, opacity: 0, stagger: .06, duration: .45, ease: 'power3.out' }) };
$('#tabs').addEventListener('click', e => { const b = e.target.closest('button'); if (b) showTab(+b.dataset.i) }); showTab(0);
// successes / failures flip cards
$('#ss').innerHTML = SS.map(([t, f, s, a]) => `<button class="flip" aria-pressed="false"><div class="in"><div class="f"><span class="mono">Insucesso · ${a}</span><div><b>${t}</b><p style="margin-top:8px">${f}</p></div><small>Virar para ver a solução ↻</small></div><div class="b"><span class="mono">Sucesso</span><div><b>${t}</b><p style="margin-top:8px">${s}</p></div><small>↻</small></div></div></button>`).join('');
$$('.flip').forEach(b => b.onclick = () => { b.classList.toggle('on'); b.setAttribute('aria-pressed', b.classList.contains('on')) });
// results bars
{ const maxT = 46, maxP = 100; $('#rbars').innerHTML = `<div class="rb hd"><span>Missão</span><div>Tempo (s)</div><div>Pontos</div></div>` + RESULT.map(([n, s, p]) => `<div class="rb"><span>${n}</span><div class="t"><i style="width:${s / maxT * 100}%"></i><span class="v">${s} s</span></div><div class="p"><i style="width:${p / maxP * 100}%"></i><span class="v">${p} pts</span></div></div>`).join('') + `<div class="rb"><span><b>Total</b></span><div class="t" style="background:none"><span class="v" style="left:0;right:auto"><b>120 s</b></span></div><div class="p" style="background:none"><span class="v" style="left:0;right:auto"><b>500 pts</b></span></div></div>` }
// gantts
function gantt(sel, rows) { const M = ['Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez']; let h = '<span class="mh" style="text-align:left">Processo</span>' + M.map(m => `<span class="mh">${m}</span>`).join(''); rows.forEach(([l, s, sp, reg]) => { h += `<div class="row"><span class="lab">${l}</span>${s ? `<span style="grid-column:span ${s}"></span>` : ''}<span class="bar${reg ? ' reg' : ''}" style="grid-column:span ${sp}">${M[s]}${sp > 1 ? '–' + M[s + sp - 1] : ''}</span>${10 - s - sp ? `<span style="grid-column:span ${10 - s - sp}"></span>` : ''}</div>` }); $(sel).innerHTML = h }
gantt('#gantt', GANTT); gantt('#ganttTE', GANTT_TE);
// methodology
$('#met').innerHTML = STEPS.map(([t, d], i) => `<div class="cell-b"><span class="big">${i + 1}</span><div><b class="t">${t}</b><p style="margin-top:8px">${d}</p></div></div>`).join('');
// GUT
let sortK = 's', sortDir = -1, nid = 0;
const prio = s => s >= 100 ? ['alta', 'Alta'] : s >= 36 ? ['media', 'Média'] : ['baixa', 'Baixa'];
function renderGut(anim) { const st = anim ? Flip.getState('#gutBody tr') : null; const rows = [...GUT].sort((a, b) => { const va = a[sortK], vb = b[sortK]; return (typeof va === 'string' ? va.localeCompare(vb, 'pt') : va - vb) * sortDir }); const body = $('#gutBody'); const ex = new Map($$('tr', body).map(r => [r.dataset.id, r])); rows.forEach(r => { let tr = ex.get(r.id); if (!tr) { tr = document.createElement('tr'); tr.dataset.id = r.id; if (r.isNew) tr.className = 'new'; const [c, l] = prio(r.s); const td = document.createElement('td'); td.textContent = r.a; tr.append(td); tr.insertAdjacentHTML('beforeend', `<td class="n">${r.g}</td><td class="n">${r.u}</td><td class="n">${r.t}</td><td class="s">${r.s}</td><td><span class="pill ${c}">${l}</span></td>`) } body.append(tr) }); if (st) Flip.from(st, { duration: .6, ease: 'power3.inOut', onEnter: els => gsap.fromTo(els, { opacity: 0, x: -30 }, { opacity: 1, x: 0, duration: .6 }) }) }
renderGut();
$$('#gutTable th[data-k]').forEach(th => th.onclick = () => { const k = th.dataset.k; sortDir = sortK === k ? -sortDir : (k === 'a' ? 1 : -1); sortK = k; $$('#gutTable th').forEach(h => h.textContent = h.textContent.replace(/ [↑↓]$/, '')); th.textContent += sortDir < 0 ? ' ↓' : ' ↑'; renderGut(true) });
const calc = () => { const g = +$('#gG').value, u = +$('#gU').value, t = +$('#gT').value; $('#oG').textContent = g; $('#oU').textContent = u; $('#oT').textContent = t; const s = g * u * t; const o = { n: +$('#gRes').textContent }; gsap.to(o, { n: s, duration: .4, onUpdate: () => $('#gRes').textContent = Math.round(o.n) }); const [c, l] = prio(s); const p = $('#gPill'); p.className = 'pill ' + c; p.textContent = l; return { g, u, t, s } };
['#gG', '#gU', '#gT'].forEach(s => $(s).addEventListener('input', calc));
$('#gutForm').addEventListener('submit', e => { e.preventDefault(); const v = calc(); GUT.push({ id: 'n' + (nid++), a: $('#gName').value.trim() || 'Nova ação', ...v, isNew: true }); sortK = 's'; sortDir = -1; renderGut(true); toast('Ação adicionada à matriz') });
// risks
{ const heat = $('#heat'); let h = ''; const col = v => v >= 12 ? '#FF5A36' : v >= 8 ? '#FF8A5C' : v >= 5 ? '#FFB547' : '#BFE6CF';
  for (let p = 5; p >= 1; p--) { h += `<span class="ax">${p}</span>`; for (let i = 1; i <= 5; i++) { const n = RISKS.filter(r => r.p === p && r.i === i).length; h += `<button class="cell" data-p="${p}" data-i="${i}" style="background:${col(p * i)}" aria-label="Probabilidade ${p}, impacto ${i}${n ? ', ' + n + ' riscos' : ''}">${p * i}${n ? `<span class="cnt">${n}</span>` : ''}</button>` } }
  h += '<span></span>' + [1, 2, 3, 4, 5].map(i => `<span class="ax">${i}</span>`).join(''); heat.innerHTML = h;
  const show = (p, i) => { $$('.cell').forEach(c => c.classList.toggle('sel', +c.dataset.p === p && +c.dataset.i === i)); const L = RISKS.filter(r => r.p === p && r.i === i); $('#riskPanel').innerHTML = L.length ? L.map(r => `<div class="risk-item"><span class="mono">Nível ${p * i} · P${p} × I${i}</span><b>${r.n}</b><p>${r.m}</p></div>`).join('') : `<div class="risk-item"><span class="mono">Nível ${p * i}</span><b>Nenhum risco mapeado</b><p>As células com número têm riscos registrados pela equipe.</p></div>`; gsap.from('#riskPanel .risk-item', { x: 24, opacity: 0, stagger: .06, duration: .5, ease: 'power3.out' }) };
  heat.addEventListener('click', e => { const c = e.target.closest('.cell'); if (c) show(+c.dataset.p, +c.dataset.i) }); show(3, 4); }
// finance
{ const max = 2125; let mode = 'rec';
  const draw = () => { const d = FIN[mode], tot = d.reduce((a, b) => a + b[1], 0); $('#bars').innerHTML = d.map(([n, v]) => `<div class="brow${mode === 'desp' ? ' exp' : ''}"><span class="nm">${n}</span><span class="tr"><i style="width:0"></i><span class="pc">${(v / tot * 100).toLocaleString('pt-BR', { maximumFractionDigits: 1 })}%</span></span><span class="vl">R$ ${brl(v)}</span></div>`).join(''); requestAnimationFrame(() => requestAnimationFrame(() => $$('#bars .tr i').forEach((el, k) => { el.style.transitionDelay = k * .07 + 's'; el.style.width = d[k][1] / max * 100 + '%' }))) };
  $$('.fin-tabs button').forEach(b => b.onclick = () => { $$('.fin-tabs button').forEach(x => x.setAttribute('aria-pressed', x === b)); mode = b.dataset.t; draw() });
  $('#bars').innerHTML = FIN.rec.map(([n, v]) => `<div class="brow"><span class="nm">${n}</span><span class="tr"><i style="width:${v / max * 100}%"></i></span><span class="vl">R$ ${brl(v)}</span></div>`).join('');
  ScrollTrigger.create({ trigger: '#bars', start: 'top 90%', once: true, onEnter: draw }); }

function setupBlocks() {
  $$('.blk .split, .band .split, #fim .split').forEach(el => gsap.from($$('.w>span', el), { yPercent: 105, duration: 1, stagger: .05, ease: 'power4.out', scrollTrigger: { trigger: el, start: 'top 88%' } }));
  $$('.chap .split').filter(el => el.id !== 'heroTitle').forEach(el => gsap.from($$('.w>span', el), { yPercent: 105, duration: 1, stagger: .05, ease: 'power4.out', scrollTrigger: { trigger: el.closest('.chap'), start: 'top 55%' } }));
  gsap.from('.mem', { y: 50, opacity: 0, duration: .9, stagger: .05, ease: 'power3.out', scrollTrigger: { trigger: '#memGrid', start: 'top 85%' } });
  $$('.grid1 > .cell-b, .te5 > div, .flip, .need span').forEach(el => gsap.from(el, { y: 30, opacity: 0, duration: .8, ease: 'power3.out', scrollTrigger: { trigger: el, start: 'top 94%' } }));
  gsap.from('.prow', { x: -20, opacity: 0, stagger: .03, duration: .6, ease: 'power3.out', scrollTrigger: { trigger: '#ptable', start: 'top 85%' } });
  $$('[data-count]').forEach(el => { const v = +el.dataset.count, o = { n: 0 }; ScrollTrigger.create({ trigger: el, start: 'top 90%', once: true, onEnter: () => gsap.to(o, { n: v, duration: 1.8, ease: 'power3.out', onUpdate: () => el.textContent = Math.round(o.n) }) }) });
  $$('[data-money]').forEach(el => { const v = +el.dataset.money, o = { n: 0 }; ScrollTrigger.create({ trigger: el, start: 'top 90%', once: true, onEnter: () => gsap.to(o, { n: v, duration: 2, ease: 'power3.out', onUpdate: () => el.textContent = brl(o.n) }) }) });
  $$('.meter i').forEach(el => gsap.to(el, { scaleX: +el.dataset.w, duration: 1.4, ease: 'power3.out', scrollTrigger: { trigger: el, start: 'top 92%' } }));
  $$('.rb .t i, .rb .p i').forEach((el, i) => gsap.to(el, { scaleX: 1, duration: 1.1, delay: (i % 9) * .05, ease: 'power3.out', scrollTrigger: { trigger: '#rbars', start: 'top 85%' } }));
  $$('.gantt').forEach(g => gsap.from($$('.bar', g), { scaleX: 0, duration: 1, stagger: .08, ease: 'power3.out', scrollTrigger: { trigger: g, start: 'top 80%' } }));
  gsap.to($$('#decQ .w'), { opacity: 1, stagger: .1, ease: 'none', scrollTrigger: { trigger: '#decQ', start: 'top 80%', end: 'bottom 40%', scrub: true } });
  gsap.fromTo('.band video', { scale: 1.25 }, { scale: 1, ease: 'none', scrollTrigger: { trigger: '.band', start: 'top bottom', end: 'bottom top', scrub: true } });
  gsap.fromTo('#fim .ph', { yPercent: 12 }, { yPercent: 0, ease: 'none', scrollTrigger: { trigger: '#fim', start: 'top bottom', end: 'bottom bottom', scrub: true } });
  gsap.matchMedia().add('(min-width:901px)', () => { const track = $('#hzTrack'); const dist = () => track.scrollWidth - innerWidth + 2 * parseFloat(getComputedStyle(track).paddingLeft); gsap.to(track, { x: () => -dist(), ease: 'none', scrollTrigger: { trigger: '#historia', start: 'top top', end: () => '+=' + dist(), pin: true, scrub: 1, invalidateOnRefresh: true, onUpdate: s => $('#hzBar').style.transform = `scaleX(${s.progress})` } }) });
  const NAMED = $$('main [data-name]');
  $('#menuList').innerHTML = NAMED.map(s => `<li><a href="#${s.id}" data-goto="${s.id}">${s.dataset.name}</a></li>`).join('');
  $('#chapnav').innerHTML = NAMED.map(s => `<button data-goto="${s.id}" aria-label="${s.dataset.name}"></button>`).join('');
  NAMED.forEach((s, i) => ScrollTrigger.create({ trigger: s, start: 'top 50%', end: 'bottom 50%', onToggle: e => { if (!e.isActive) return; chapName = s.dataset.name; $('#chapLabel').textContent = `${String(i + 1).padStart(2, '0')} — ${s.dataset.name}`; $$('#chapnav button').forEach((b, j) => b.classList.toggle('on', j === i)) } }));
  ScrollTrigger.create({ start: 0, end: 'max', onUpdate: s => $('.progress').style.transform = `scaleX(${s.progress})` });
}

const menu = $('#menu');
function openMenu() { menu.style.visibility = 'visible'; gsap.to(menu, { clipPath: 'inset(0 0 0% 0)', duration: .8, ease: 'expo.inOut' }); gsap.from('#menu li', { y: 40, opacity: 0, stagger: .02, duration: .5, delay: .3, ease: 'power3.out' }); $('#menuBtn').setAttribute('aria-expanded', 'true'); lenis?.stop() }
function closeMenu() { if ($('#menuBtn').getAttribute('aria-expanded') !== 'true') return; gsap.to(menu, { clipPath: 'inset(0 0 100% 0)', duration: .6, ease: 'expo.inOut', onComplete: () => menu.style.visibility = 'hidden' }); $('#menuBtn').setAttribute('aria-expanded', 'false'); lenis?.start() }
$('#menuBtn').onclick = openMenu; $('#menuClose').onclick = closeMenu; addEventListener('keydown', e => { if (e.key === 'Escape') closeMenu() });
if (!TOUCH && !RM) { const c = $('.cur'); const qx = gsap.quickTo(c, 'x', { duration: .15 }), qy = gsap.quickTo(c, 'y', { duration: .15 }), lx = gsap.quickTo(curL, 'x', { duration: .25 }), ly = gsap.quickTo(curL, 'y', { duration: .25 }); addEventListener('pointermove', e => { qx(e.clientX); qy(e.clientY); lx(e.clientX + 14); ly(e.clientY + 12) }) }
let tt; function toast(m) { const t = $('#toast'); t.textContent = m; t.classList.add('on'); clearTimeout(tt); tt = setTimeout(() => t.classList.remove('on'), 2400) }
$$('[data-copy]').forEach(b => b.onclick = () => { const v = b.dataset.copy; (navigator.clipboard?.writeText(v) || Promise.reject()).then(() => toast(v + ' copiado')).catch(() => toast('Perfil: ' + v)) });
$('#toTop').onclick = () => goto('c-hero');

addEventListener('resize', () => { resize(); ScrollTrigger.refresh() });
async function boot() {
  resize(); frame(); setupBlocks(); setupStory(); ScrollTrigger.sort(); ScrollTrigger.refresh();
  if (RM) { $('#loader').remove(); togglePower(true); return }
  const n = { v: 0 };
  await gsap.to(n, { v: 100, duration: 1.3, ease: 'power2.inOut', onUpdate: () => { $('#ldn').textContent = Math.round(n.v); $('#ldb').style.width = n.v + '%' } });
  gsap.timeline()
    .to('#loader', { yPercent: -100, duration: 1, ease: 'expo.inOut' }).add(() => $('#loader').remove())
    .from('#ghost', { yPercent: 30, opacity: 0, duration: 1.4, ease: 'expo.out' }, .35)
    .from($$('#heroTitle .w>span'), { yPercent: 110, duration: 1.1, stagger: .06, ease: 'power4.out' }, .5)
    .from('.hero-top, .hero-ctrl, .scrollcue', { y: 20, opacity: 0, duration: .8, stagger: .08 }, .7)
    .fromTo(intro, { drop: 5, spin: -3 }, { drop: 0, duration: 1.5, ease: 'bounce.out' }, .15)
    .to(intro, { spin: 0, duration: 2.2, ease: 'expo.out' }, .15)
    .add(() => togglePower(true), 1.8);
}
(document.fonts?.ready || Promise.resolve()).then(boot);
